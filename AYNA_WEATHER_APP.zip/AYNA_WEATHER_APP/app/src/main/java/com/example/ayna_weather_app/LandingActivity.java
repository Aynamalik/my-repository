package com.example.ayna_weather_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class LandingActivity extends AppCompatActivity {
    private Button weatherButton, logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing); // Ensure this layout exists

        // Initialize UI elements
        weatherButton = findViewById(R.id.weatherButton);
        logoutButton = findViewById(R.id.logoutButton);

        // Set background color dynamically (Fix potential error)
        weatherButton.setBackgroundColor(ContextCompat.getColor(this, R.color.buttonColor));

        // Navigate to WeatherActivity
        weatherButton.setOnClickListener(v -> {
            Intent intent = new Intent(LandingActivity.this, WeatherActivity.class);
            startActivity(intent);
        });

        // Logout and go to LoginActivity
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(LandingActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
